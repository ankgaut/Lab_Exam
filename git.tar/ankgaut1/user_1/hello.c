#include<stdio.h>

void microkernel_sendmsg(char *);

void main(){
    printf("HelloWorld!\n");
    printf("This must be a monolithic design\n");
    microkernel_sendmsg("is more protable");
    printf("patch is applied\n");
}

void microkernel_sendmsg(char *a){
    printf("microkernel:%s\n",a);
}
