#!/usr/bin/python

#Ankur Gautam
#160127
#Feb 1 2018, 5:15 pm

from sys import argv
import re

script, num, b = argv

k = len(b)
if k == 1:
    b = ord(b[0]) - 48
elif k==2:
    b = (ord(b[0])-48)*10 + (ord(b[1]) - 48)
else:
    print "Invalid Input"
    exit(0)

if(2<=b<=36):
    pass
else:
    print "Invalid Input"
    exit(0)

valid1 = re.match(r"^(-)?[A-Z0-9]{1,}\.[A-Z0-9]{1,}$",num)
valid2 = re.match(r"^(-)?[A-Z0-9]{1,}$",num)

if (valid1 is None) and (valid2 is None):
    print "Invalid Input"
    exit(0)



def check(string,index,base):
    ch = string[index]
    
    if 47 < ord(ch) < 58:
        k = (ord(ch) - 48)
        if k < base:
            return k
        else:
            print "Invalid Input"
            exit(0)
    elif 64 < ord(ch) < 91:
        k = (ord(ch) - 55)
        if k < base:
            return k
        else:
            print "Invalid Input"
            exit(0)

#print the - sign if present
flag_neg=0
flag=0
try:
    num.index("-")
except ValueError:
    pass
else:
    num=num.strip("-")
    flag_neg=1






answer = 0
try:
    num.index(".")
except ValueError:
    flag = 1
else:
    flag = 2
finally:

    if flag==1:
        multi = 1
        for i in range(len(num)):
            k=-i-1
            answer = answer + (check(num,k,b))*multi
            multi = multi*b
            
    elif flag==2:
        num = num.strip("0")
        numbers = num.split(".")
        multi = 1
        for i in range(len(numbers[0])):
            k=-i-1
            answer = answer + (check(numbers[0],k,b))*multi
            multi = multi*b
        
        multi = 1.0 / b
        for i in range(len(numbers[1])):
            answer = answer + (check(numbers[1],i,b))*multi
            multi = multi / b

    if ( 0 <= answer <= 999999999 ):
        if flag_neg == 0:
            print answer
        else:
            answer = -answer
            print answer
    else:
        print "Invalid Input"
        exit(1)
 
        


