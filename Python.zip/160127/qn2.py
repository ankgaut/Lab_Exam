#!/usr/bin/python
#Ankur Gautam
#160127
#Feb 2 4:10 pm

import numpy as np
from matplotlib import pyplot as plt
import random

################################Step 1:
train = np.genfromtxt('train.csv',delimiter=',',skip_header=1)
nrows , ncols = train.shape
ones = np.ones((10000,1))
#Change 8 to 10000 before submitting

X = train[0:nrows,0:1,dtype='float64']
X_train = np.hstack((ones,X))
Y_train = train[0:nrows,1:2]

####################################Step 2:

w = np.random.rand(2,1)
print w
####################################Step 3:

Z = np.dot((w.transpose()),(X_train.transpose())) 
plt.plot(X,Y_train,'bo')
plt.plot(X,Z.T,'k')
plt.title('step 3')
#plt.show()

###################################Step 4:

inv = np.linalg.inv((X_train.T).dot(X_train))
w_direct = inv.dot((X_train.T).dot(Y_train))
plt.plot(X,Y_train,'bo')
Z = (w_direct.T).dot(X_train.T)
plt.plot(X,Z.T,'k')
plt.title('step 4')
#plt.show()

#####################################Step 5:

eta = 0.0001

for nepoch in range(2):
    for row in train:       
        x , y = row        
        one = 1
        x1 = np.hstack((one,x))
        x1 = x1.T
        c = (w.T).dot(x1)        
        c -= y        
        c = np.ravel(c)
        cons = c.sum()              
        cons *= eta       
        x1 = np.matrix(x1)
        x1 = x1.T        
        print x1, w.shape
        k = cons*(np.array(x1))
        print k , k.shape
        w -= k
        print w.shape
               
        if row%1000==0:
        
            Z = np.dot((w.transpose()),(X_train.transpose())) 
            plt.plot(X,Y_train,'bo')
            plt.plot(X,Z.T,'k')
            plt.title('step 5')
            plt.show()
   
########################################Step 6:
            
Z = np.dot((w.transpose()),(X_train.transpose())) 
plt.plot(X,Y_train,'bo')
plt.plot(X,Z.T,'k')
plt.title('step 6')
plt.show()
            

      
