#!/bin/bash

#Ankur Gautam
#160127
#Mar 2 2018, 5:04 am
 
 


xml=$1
named=`pwd`

fflag=0

IFS=$'\n'
for i in `cat $xml`
do
    line="$i"
    
    if [ $fflag -eq 1 ]
    then 
        
        fe1='^[[:blank:]]*<name>'    
        fe2='^[[:blank:]]*<size>'
        fe3='^[[:blank:]]*<[/]file>'
       
        if [[ $line =~ $fe1 ]]
        then
        
            name=$(echo $line | sed 's/^[[:blank:]]*<name> *//')
            namef=$(echo $name | sed 's/ *<\/name>[[:blank:]]*$//')
            
            mv untitlef "$namef"
            
    
        elif [[ $line =~ $fe2 ]]
        then
            size=$(echo $line | sed 's/^[[:blank:]]*<size> *//')
            sizef=$(echo $size | sed 's/ *<\/size>[[:blank:]]*$//')
            
                     
                        
            x=0
            while [ $x -lt $sizef ];
            do 
                echo -n a >> $namef
                ((x++))
            done
            
        
        elif [[ $line =~ $fe3 ]]
        then
        
            fflag=0
            
        fi
               
    fi
    
    if [ $fflag -eq 0 ]
    then
        re1='^[[:blank:]]*<dir>'
        re2='^[[:blank:]]*<name>'
        re3='^[[:blank:]]*<file>'
        re4='^[[:blank:]]*<[/]dir>'
    
        if [[ $line =~ $re1 ]] 
        then 
        
            mkdir untitled            
            named=untitled
            
            cd untitled
            
        
        elif [[ $line =~ $re2 ]]
        then
        
            name=$(echo $line | sed 's/^[[:blank:]]*<name> *//')
            named=$(echo $name | sed 's/ *<\/name>[[:blank:]]*$//')
        
            mv ../untitled "../$named"
            
        
        elif [[ $line =~ $re3 ]]
        then

            touch untitlef
            namef=untitlef
            
            fflag=1
    
        elif [[ $line =~ $re4 ]]
        then
            cd .. 
            
        fi
    fi
    
        
     
    
done



