#!/usr/bin/python

#Ankur Gautam 
#160127
#March 2 2018, 12:41am

import sys
from math import ceil
from math import log

def tree_printer(li,i,space,depth,s,l):
    
    key = ( s + l) / 2
    
    if depth < i:
        tree_printer(li,i,space,depth+1,s,key-1)
        tree_printer(li,i,space,depth+1,key+1,l)
    elif depth == i:
        if s>l:
            sys.stdout.write('  ')
        else:
            print "\b%2d"%(li[key]),
            sys.stdout.write(' ')
            
            
        for z in range(space):
            sys.stdout.write(' ')
        return
    else:
        return 
        
    



script, arr = sys.argv

arr = arr.strip('[')
arr = arr.strip(']')
lis = arr.split(',')
n = len(lis)

li = []
for w in range(n):
    ele = lis.pop()
    ele = int(ele)    
    li.append(ele)
    
li.sort()



ht = ceil(log(n + 1 , 2)) - 1
ht = int(ht)



for i in range(ht + 1):
    
    padding = 2**(ht - i) - 1
    
    space = padding*2 + 1
    space = space * 2
    padding = padding * 2
    for z in range(padding):
        sys.stdout.write(' ')
      
      
    tree_printer(li,i,space,0,0,n - 1)
      
        
    print " "
            
 
    
